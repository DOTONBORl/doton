const tabMenu = document.querySelectorAll('.tab-menu li');
const tabContent = document.querySelectorAll('#tab-content>div');
const highlight = document.querySelector('.highlight');

function showContent(num){
  tabContent.forEach((item) =>{
    item.style.display = `none`;
  });
  tabContent[num].style.display = `block`;
  
  tabMenu.forEach(function (item){
    item.classList.remove('active'); 
  });
  tabMenu[num].classList.add('active')
  
};

tabMenu.forEach(function (item,index){
  item.addEventListener('click', function (e){
    e.preventDefault();
    showContent(index);
    console.log(this.offsetLeft, this.offsetWidth);
    highlight.style.left = `${this.offsetLeft}px`;
    highlight.style.width = `${this.offsetWidth}px`;
  });
});
showContent(0);
  
