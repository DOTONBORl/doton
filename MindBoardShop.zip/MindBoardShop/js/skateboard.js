// $(function(){

//   $('.leftBtn').click(function(){
//     // li중의 두번째 이미지
//     $('#best>li').ep(1).css({'transform':'scale(1.4)','transition':'all 0.3','z-index':'9'})
//     .siblings().css({'transform':'scale(1)','transition':'all 0.3','z-index':'8'});
//     // 2번째 이미지가 크기가 변경된느 css적용 + 나머지는 원래대로

//     $('#best').filter(':not(:animated)').animate({'margin-left':'320px'},300,function(){
//      let last = $('#best>li').last();/* 마지막 이미지 */
//      $(this).prepend(last);/* 마지막 이미지를 맨앞쪽으로 이동해서 대기*/
//      $('#best').css('margin-left','0');
//     });
//   });

//   $('.rightBtn').click(function(){
//     // li중의 두번째 이미지
//     $('#best>li').ep(3).css({'transform':'scale(1.4)','transition':'all 0.3','z-index':'9'})
//     .siblings().css({'transform':'scale(1)','transition':'all 0.3','z-index':'8'});
//     // 4번째 이미지가 크기가 변경된느 css적용 + 나머지는 원래대로

//     $('#best').filter(':not(:animated)').animate({'margin-left':'-320px'},300,function(){
//      let first = $('#best>li').first();/* 마지막 이미지 */
//      $(this).append(first);/* 마지막 이미지를 맨앞쪽으로 이동해서 대기*/
//      $('#best').css('margin-left','0');
//   });

//   });
  
// });

$(function(){

  $('.leftBtn').click(function(){
    // li중의 두번째 이미지
    $('#best').find('li').eq(1).css({'transform':'scale(1.3)','transition':'all 0.3', 'z-index:':'9'})
    .siblings().css({'transform':'scale(0.85)','transition':'all 0.3', 'z-index:':'8'});
    // 2번째 이미지가 크기가 변경된느 css적용 + 나머지는 원래대로

    $('#best').filter(':not(:animated)').animate({'margin-left':'200px'},300,function(){/* li 크기만큼 이동 */
      let last = $('#best>li').last(); /* 마지막 이미지 */
      $(this).prepend(last);/* 마지막 이미지를 맨앞쪽으로 이동해서 대기*/
      $('#best').css('margin-left','0');  
    });

  });
  $('.rightBtn').click(function(){
   // li중의 두번째 이미지
   $('#best').find('li').eq(3).css({'transform':'scale(1.3)','transition':'all 0.3', 'z-index:':'9'})
   .siblings().css({'transform':'scale(0.85)','transition':'all 0.3', 'z-index:':'8'});
   // 4번째 이미지가 크기가 변경된느 css적용 + 나머지는 원래대로

   $('#best').filter(':not(:animated)').animate({'margin-left':'-200px'},300,function(){/* li 크기만큼 이동 */
     let first = $('#best>li').first(); /* 마지막 이미지 */
     $(this).append(first);/* 마지막 이미지를 맨앞쪽으로 이동해서 대기*/
     $('#best').css('margin-left','0');  
   });

  });

}); //jQB


// const topBtn = document.getElementById('topBtn');
// // console.log(topBtn)
// topBtn.addEventListener('click',function(){
//   window.scrollTo(0,0)
// });

const gnbBox = document.getElementById("top2");
const sublogo = document.getElementById("sublogo");
const topdd = document.getElementById("top");


window.addEventListener("scroll",(event) => {
let scrollY = document.scrollingElement.scrollTop;
// console.log(scrollY)
if(scrollY === 0){
  gnbBox.style.opacity = '1'
  sublogo.style.opacity = '1'
  topdd.style.height = '160px'
  topdd.style.opacity = '1'
  topdd.style.transition = 'all 0.3s'
  sublogo.style.transition = 'all 0.7s'
  gnbBox.style.transition = 'all 0.7s'
} else {
  gnbBox.style.opacity = '0'
  sublogo.style.opacity = '0'
  topdd.style.height = '90px'
  topdd.style.transition = 'all 0.3s'
  sublogo.style.transition = 'all 0.15s'
  gnbBox.style.transition = 'all 0.15s'
}
});

  // const popup = document.getElementsByClassName("pop");
  // const poppop = document.getElementById("popupBox")
  // //  console.log(popupBox)
  // window.addEventListener('click',function(){
  // let pop = (this).document.index()

  // poppop.fadeIn(600)
  // poppop.find('img').attr('src','images/question-mark'+(pop+1)+'png');

  // let popCream_title = popup.ep(pop).find('h3').text();
  // let popCream_txt = popup.ep(pop).find('p').txt();

  // poppop.find('h4').text(popCream_title);
  // poppop.find('p').text(popCream_txt);

  // });

  // poppop.find('figure').click(function(){
  //   poppop.fadeOut(600);
  // });

 $(function(){
   'use strict';
     $('.boarder>figure>figcaption>img').click(function(){
  
       let idx=$(this).parent().parent().parent().index();
      //  console.log(idx);

      $('#popupBox>figure').fadeIn(600);
      $('#boarderWrap').css({'opacity':'0.3'});
       
      $('#popupBox').find('img').attr('src','images/dak'+(idx+1)+'.jpg');
  

       let iceCream_title = $('.boarder').eq(idx).find('h3').text();
       let iceCream_txt1 = $('.boarder').eq(idx).find('.p1').text();
       let iceCream_txt2 = $('.boarder').eq(idx).find('.p2').text();
       let iceCream_txt3 = $('.boarder').eq(idx).find('.p3').text();
      //  console.log(iceCream_title );
      //  console.log(iceCream_txt );
  
       $('#popupBox').find('h4').text(iceCream_title).css('display','block');
       $('#popupBox').find('.p1_box').text(iceCream_txt1).css('display','block');
       $('#popupBox').find('.p2_box').text(iceCream_txt2).css('display','block');
       $('#popupBox').find('.p3_box').text(iceCream_txt3).css('display','block');
  
     });
  
     $('#popupBox').find('figure').click(function(){

      $('#popupBox>figure').fadeOut(600);
      $('#boarderWrap').css({'opacity':'1'});

     });
   }); //jQB
