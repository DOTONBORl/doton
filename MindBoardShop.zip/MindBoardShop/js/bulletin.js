// const topBtn = document.getElementById('topBtn');
// // console.log(topBtn)
// topBtn.addEventListener('click',function(){
//   window.scrollTo(0,0)
// });

const gnbBox = document.getElementById("top2");
const sublogo = document.getElementById("sublogo");
const topdd = document.getElementById("top");

window.addEventListener("scroll",(event) => {
let scrollY = document.scrollingElement.scrollTop;
// console.log(scrollY)
if(scrollY === 0){
  gnbBox.style.opacity = '1'
  sublogo.style.opacity = '1'
  topdd.style.height = '160px'
  topdd.style.opacity = '1'
  topdd.style.transition = 'all 0.3s'
  sublogo.style.transition = 'all 0.7s'
  gnbBox.style.transition = 'all 0.7s'
}
else {
  gnbBox.style.opacity = '0'
  sublogo.style.opacity = '0'
  topdd.style.height = '90px'
  topdd.style.transition = 'all 0.3s'
  sublogo.style.transition = 'all 0.15s'
  gnbBox.style.transition = 'all 0.15s'
}
});

let objTop1 = document.querySelector('.mid1');
let objTop1_iframe = document.querySelector('.mid1>iframe');
let objTop2 = document.querySelector('.mid2');
let objTop2_iframe = document.querySelector('.mid2>iframe');
let objTop3 = document.querySelector('.mid3');
let objTop3_iframe = document.querySelector('.mid3>iframe');
let objTop4 = document.querySelector('.mid4');
let objTop4_iframe = document.querySelector('.mid4>iframe');
let objTop5 = document.querySelector('.mid5');
let objTop5_iframe = document.querySelector('.mid5>iframe');

function obj1(){
  objTop1_iframe.style.opacity = '1'
}

window.addEventListener('scroll',(event) => {
let scrolling = document.scrollingElement.scrollTop
console.log(scrolling)

/* if(scrolling > 0){
  objTop1_iframe.style.opacity = '1'
} */
if(scrolling > 95){
  objTop2_iframe.style.opacity = '1'
}
if(scrolling > 450){
  objTop3_iframe.style.opacity = '1'
}
if(scrolling > 850){
  objTop4_iframe.style.opacity = '1'
}
if(scrolling > 1350){
  objTop5_iframe.style.opacity = '1'
}
});
