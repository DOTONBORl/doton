// $(function(){

//   $('.leftBtn').click(function(){
//     // li중의 두번째 이미지
//     $('#best>li').ep(1).css({'transform':'scale(1.4)','transition':'all 0.3','z-index':'9'})
//     .siblings().css({'transform':'scale(1)','transition':'all 0.3','z-index':'8'});
//     // 2번째 이미지가 크기가 변경된느 css적용 + 나머지는 원래대로

//     $('#best').filter(':not(:animated)').animate({'margin-left':'320px'},300,function(){
//      let last = $('#best>li').last();/* 마지막 이미지 */
//      $(this).prepend(last);/* 마지막 이미지를 맨앞쪽으로 이동해서 대기*/
//      $('#best').css('margin-left','0');
//     });
//   });

//   $('.rightBtn').click(function(){
//     // li중의 두번째 이미지
//     $('#best>li').ep(3).css({'transform':'scale(1.4)','transition':'all 0.3','z-index':'9'})
//     .siblings().css({'transform':'scale(1)','transition':'all 0.3','z-index':'8'});
//     // 4번째 이미지가 크기가 변경된느 css적용 + 나머지는 원래대로

//     $('#best').filter(':not(:animated)').animate({'margin-left':'-320px'},300,function(){
//      let first = $('#best>li').first();/* 마지막 이미지 */
//      $(this).append(first);/* 마지막 이미지를 맨앞쪽으로 이동해서 대기*/
//      $('#best').css('margin-left','0');
//   });

//   });
  
// });

$(function(){

  $('.leftBtn').click(function(){
    // li중의 두번째 이미지
    $('#best').find('li').eq(1).css({'transform':'scale(1.3)','transition':'all 0.3', 'z-index:':'9'})
    .siblings().css({'transform':'scale(0.85)','transition':'all 0.3', 'z-index:':'8'});
    // 2번째 이미지가 크기가 변경된느 css적용 + 나머지는 원래대로

    $('#best').filter(':not(:animated)').animate({'margin-left':'200px'},300,function(){/* li 크기만큼 이동 */
      let last = $('#best>li').last(); /* 마지막 이미지 */
      $(this).prepend(last);/* 마지막 이미지를 맨앞쪽으로 이동해서 대기*/
      $('#best').css('margin-left','0');  
    });

  });
  $('.rightBtn').click(function(){
   // li중의 두번째 이미지
   $('#best').find('li').eq(3).css({'transform':'scale(1.3)','transition':'all 0.3', 'z-index:':'9'})
   .siblings().css({'transform':'scale(0.85)','transition':'all 0.3', 'z-index:':'8'});
   // 4번째 이미지가 크기가 변경된느 css적용 + 나머지는 원래대로

   $('#best').filter(':not(:animated)').animate({'margin-left':'-200px'},300,function(){/* li 크기만큼 이동 */
     let first = $('#best>li').first(); /* 마지막 이미지 */
     $(this).append(first);/* 마지막 이미지를 맨앞쪽으로 이동해서 대기*/
     $('#best').css('margin-left','0');  
   });

  });

}); //jQB


const topBtn = document.getElementById('topBtn');
// console.log(topBtn)
topBtn.addEventListener('click',function(){
  window.scrollTo(0,0)
});

const gnbBox = document.getElementById("top2");
const sublogo = document.getElementById("sublogo");
const topdd = document.getElementById("top");

window.addEventListener("scroll",(event) => {
let scrollY = document.scrollingElement.scrollTop;
// console.log(scrollY)
if(scrollY === 0){
  gnbBox.style.opacity = '1'
  sublogo.style.opacity = '1'
  topdd.style.height = '160px'
  topdd.style.opacity = '1'
  topdd.style.transition = 'all 0.3s'
  sublogo.style.transition = 'all 0.7s'
  gnbBox.style.transition = 'all 0.7s'
}
else {
  gnbBox.style.opacity = '0'
  sublogo.style.opacity = '0'
  topdd.style.height = '90px'
  topdd.style.transition = 'all 0.3s'
  sublogo.style.transition = 'all 0.15s'
  gnbBox.style.transition = 'all 0.15s'
}
});

$(function(){

  $('.insta').mouseenter(function(){
    // li중의 두번째 이미지
    $(this).css('opacity','1')
    .siblings().css('opacity','0.3');


    // 2번째 이미지가 크기가 변경된느 css적용 + 나머지는 원래대로

    // $('#best').filter(':not(:animated)').animate({'margin-left':'200px'},300,function(){/* li 크기만큼 이동 */
    //   let last = $('#best>li').last(); /* 마지막 이미지 */
    //   $(this).prepend(last);/* 마지막 이미지를 맨앞쪽으로 이동해서 대기*/
    //   $('#best').css('margin-left','0');  
    // });

  });
  $('.insta').mouseleave(function(){
    // li중의 두번째 이미지
    $('.insta').css('opacity','1');
  });
});




/* 
const instaAll = document.querySelectorAll('.insta');

instaAll.addEventListener('mouseover',() => {
  for(let i = 0;i < instaAll.length;i++){
    if(i <= this){
      this.style.opacity = '0.3';
    }
  }
}); */


/* instaAll.forEach((el) => {
  el.addEventListener('mouseover',() => {
    el.style.opacity = '0.3';
    this.style.opacity = '1';
  })
})
 */

let objTop1 = document.querySelector('.new01');
let objTop1_img = document.querySelector('.new01>a');
let objTop2 = document.querySelector('.new02');
let objTop2_img = document.querySelector('.new02>a');
let objTop3 = document.querySelector('.new03');
let objTop3_img = document.querySelector('.new03>as');

window.addEventListener('scroll',(event) => {
let scrolling = document.scrollingElement.scrollTop
// console.log(scrolling)

// console.log(objTop1)
console.log(objTop2)
// console.log(objTop3)

if(scrolling > 95){
  objTop1.style.opacity = '1'
  objTop1.style.left = '13%'
  objTop1_img.style.transform = 'skewX(-17deg)'
}
if(scrolling > 400){
  objTop2.style.opacity = '1'
  objTop2.style.right = '13%'
  objTop2_img.style.transform = 'skewX(17deg)'  
}
if(scrolling > 700){
  objTop3.style.opacity = '1'
  objTop3.style.left = '13%'
  objTop3_img.style.transform = 'skewX(-17deg)'
}
});