const moo1 = document.querySelector('.item1')
const moo2 = document.querySelector('.item2')
const moo3 = document.querySelector('.item3')
const moo4 = document.querySelector('.item4')
const moo5 = document.querySelector('.item5')
const popup = document.getElementById('popupBox')

moo1.addEventListener('click',() => {
  popup.style.transition = 'all 0.5s'
  popup.style.opacity = '1'
  });
  
  popup.addEventListener('click',() => {
  popup.style.transition = 'all 0.5s'
  popup.style.opacity = '0'
  });
moo2.addEventListener('click',() => {
  popup.style.transition = 'all 0.5s'
  popup.style.opacity = '1'
  });
  
  popup.addEventListener('click',() => {
  popup.style.transition = 'all 0.5s'
  popup.style.opacity = '0'
  });
moo3.addEventListener('click',() => {
  popup.style.transition = 'all 0.5s'
  popup.style.opacity = '1'
  });

  popup.addEventListener('click',() => {
  popup.style.transition = 'all 0.5s'
  popup.style.opacity = '0'
  });
moo4.addEventListener('click',() => {
  popup.style.transition = 'all 0.5s'
  popup.style.opacity = '1'
  });
  
  popup.addEventListener('click',() => {
  popup.style.transition = 'all 0.5s'
  popup.style.opacity = '0'
  });
moo5.addEventListener('click',() => {
  popup.style.transition = 'all 0.5s'
  popup.style.opacity = '1'
  });
  
  popup.addEventListener('click',() => {
  popup.style.transition = 'all 0.5s'
  popup.style.opacity = '0'
  });


const rightBtn = document.querySelector('.rightBtn');
const leftBtn = document.querySelector('.leftBtn');
const radarWrap = document.getElementById('radar');
let i = 0;
rightBtn.addEventListener('click',() => {
  if(i === 0){
    radarWrap.style.transform = 'translateX(-20%)'
    i++;    
  } else if(i === 1){
    radarWrap.style.transform = 'translateX(-40%)'
    i++;    
  } else if(i === 2){
    radarWrap.style.transform = 'translateX(0%)'
    i = i * 0    
  }
});
leftBtn.addEventListener('click',() => {
  if(i === 0){
    radarWrap.style.transform = 'translateX(20%)'
    i++;    
  } else if(i === 1){
    radarWrap.style.transform = 'translateX(40%)'
    i++;    
  } else if(i === 2){
    radarWrap.style.transform = 'translateX(0%)'
    i = i * 0
  }
});